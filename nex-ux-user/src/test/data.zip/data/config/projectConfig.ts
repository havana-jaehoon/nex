import { NexNode } from "type/NexNode";

export const projectConfig: NexNode[] = [
    {
        type: "project",
        name: "nex-admin",
        dispName: "NexUX Admin",
        description: "NexUX Admin Project",
    },
];