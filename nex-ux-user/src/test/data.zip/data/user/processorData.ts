export const processorData = [
  [
    "folder",
    "/nex-admin",
    "",
    "/common/",
    "common",
    "공용",
    "공용 프로세스 폴더",
    "",
    "",
  ],
  [
    "processor",
    "/nex-admin",
    "",
    "/common/transparent/",
    "transparent",
    "기본 프로세스", // "변환없이 수집하는 프로세스"
    "기본 프로세스",
    "", //icon
    "", //color
    "0.2", //version
    "0.1, 0.2", // version history
  ],
];
